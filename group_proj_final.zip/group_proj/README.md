# Booth_FinalProj
Initial Project commit
This project uses Image Steganography to encode or decode a message hidden in a png file

encryption command
./BoothFinalProj.exe src_image.pbm dest_image.pbm message.txt

decryption command
./BoothFinalProj.exe src_image_decrypt.pbm decrypted.txt
